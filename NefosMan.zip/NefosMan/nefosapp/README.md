To install dependencies:
```sh
bun install
```

To run:
```sh
bun run dev
```


pnpm drizzle-kit generate
bun run src/migrate.ts

open http://localhost:3000


# to arxeio schema.ts exoume ta antikeimena (customer, phone, address) ta opoia tha ftiaxtoun kai stin vasi
# to arxeio migrate.ts exei kapoies entoles sundesis sti vasi kai dimiourgias twn pinakwn
 