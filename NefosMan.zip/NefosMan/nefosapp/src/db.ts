import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import * as schema from './schema';

// export const connection = await mysql.createConnection({
//   host: process.env.DB_HOST,
//   user: process.env.DB_USER,
//   password: process.env.DB_PASSWORD,
//   database: process.env.DB_NAME,
//   multipleStatements: true,
// });

async function connectWithRetry(attempt = 1, maxAttempts = 10) {
  try {
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      multipleStatements: true,
    });
    console.log('Successfully connected to the database');
    return connection;
  } catch (error) {
    if (attempt === maxAttempts) {
      console.error('Max retry attempts reached. Unable to connect to the database.');
      throw error;
    }
    console.log(`Unable to connect to the database. Retrying in 5 seconds... (Attempt ${attempt}/${maxAttempts})`);
    await new Promise(resolve => setTimeout(resolve, 5000));
    return connectWithRetry(attempt + 1, maxAttempts);
  }
}

export const connection = await connectWithRetry();
export const db = drizzle(connection, { schema, mode: 'planetscale' });
