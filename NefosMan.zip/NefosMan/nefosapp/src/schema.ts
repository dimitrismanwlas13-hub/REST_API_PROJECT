import { mysqlTable, varchar, date, index, text, int, check, foreignKey } from 'drizzle-orm/mysql-core';
import { randomUUID } from 'crypto';


// Πίνακας Πελατών
export const customers = mysqlTable('customers', {
  id: varchar('id', { length: 36 }).primaryKey().default(() => randomUUID()),
  createdAt: date('created_at').default(() => new Date().toISOString().split('T')[0]),
  identityNumber: varchar('identity_number', { length: 8 }).unique().notNull(),
  firstName: varchar('first_name', { length: 256 }).notNull(),
  lastName: varchar('last_name', { length: 256 }).notNull(),
  gender: varchar('gender', { length: 6 }).notNull(),
  birthDate: date('birth_date').notNull(),
},
  //ελεγχοι ωστε τα πεδια να παιρνουν τις σωστές τιμές βάσει περιορισμών
  (customers) => ({
    //το id ταυτοτητας πρεπει να ειναι index
    identityNumberIdx: index('identity_number_idx').on(customers.identityNumber),
    //το φυλλο πρεπει να ειναι είτε male είτε female
    genderCheck: check('gender_check', `gender IN ('male', 'female')`),
    //ελεγχος εαν η ηλικια του είναι μεγαλύτερη από 16
    birthDateCheck: check('birth_date_check', `birth_date < DATE_SUB(CURRENT_DATE, INTERVAL 16 YEAR)`),
    firstNameCheck: check('first_name_check', `first_name REGEXP '^[A-Z][a-z]{2,}$'`),
    lastNameCheck: check('last_name_check', `last_name REGEXP '^[A-Z][a-z]{2,}$'`),
    identityNumberCheck: check('identity_number_check', `identity_number REGEXP '^[A-Z]{2}[0-9]{6}$'`),
  }));

// Πίνακας Διευθύνσεων
export const addresses = mysqlTable('addresses', {
  id: int('id').primaryKey().autoincrement(),
  customerId: varchar('customer_id', { length: 36 }).notNull().references(() => customers.id),
  address: varchar('address', { length: 256 }).notNull(),
}, (addresses) => ({
  customerIdIdx: index('customer_id_idx').on(addresses.customerId),
}));

// Πίνακας Τηλεφωνικών Αριθμών
export const phoneNumbers = mysqlTable('phone_numbers', {
  id: int('id').primaryKey().autoincrement(),
  customerId: varchar('customer_id', { length: 36 }).notNull().references(() => customers.id),
  phoneNumber: varchar('phone_number', { length: 15 }).notNull(),
}, (phoneNumbers) => ({
  customerIdIdx: index('customer_id_idx').on(phoneNumbers.customerId),
}));
