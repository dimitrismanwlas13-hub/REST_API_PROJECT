import { drizzle } from 'drizzle-orm/mysql2';
import { migrate } from 'drizzle-orm/mysql2/migrator';
import mysql from 'mysql2/promise';

const MAX_RETRIES = 30;
const RETRY_INTERVAL = 2000; // 2 seconds

async function connectWithRetry(retries = MAX_RETRIES): Promise<mysql.Connection> {
  try {
    console.log(`Attempting to connect to the database (${MAX_RETRIES - retries + 1}/${MAX_RETRIES})...`);
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      multipleStatements: true,
    });
    console.log('Successfully connected to the database!');
    return connection;
  } catch (error) {
    if (retries > 0) {
      console.log(`Failed to connect. Retrying in ${RETRY_INTERVAL / 1000} seconds...`);
      await new Promise(resolve => setTimeout(resolve, RETRY_INTERVAL));
      return connectWithRetry(retries - 1);
    }
    throw new Error('Max retries reached. Could not connect to the database.');
  }
}

const runMigrations = async () => {
  console.log('Migration process starting...');

  let connection;
  try {
    connection = await connectWithRetry();
    const db = drizzle(connection);

    console.log('Starting migration...');
    await migrate(db, { migrationsFolder: './drizzle' });

    console.log('Migration completed successfully');
  } catch (error) {
    console.error('Error during migration:', error);
    process.exit(1);
  } finally {
    if (connection) {
      console.log('Closing database connection...');
      await connection.end();
      console.log('Database connection closed');
    }
    console.log('Migration process finished');
  }
};

runMigrations().catch((error) => {
  console.error('Unhandled error during migration:', error);
  process.exit(1);
});