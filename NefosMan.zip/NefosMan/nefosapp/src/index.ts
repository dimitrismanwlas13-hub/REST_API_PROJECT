import { Hono } from 'hono'
import { drizzle } from "drizzle-orm/mysql2";
import { createConnection } from "mysql2/promise";
import { mysqlTable, varchar, int } from 'drizzle-orm/mysql-core';
import * as schema from './schema';
import { customers, addresses, phoneNumbers } from './schema';
import { randomUUID } from 'crypto';
import { eq, like, and, or, desc, asc } from 'drizzle-orm';

// Log environment variables (DO NOT log passwords in production)
console.log('DB_HOST:', process.env.DB_HOST);
console.log('DB_USER:', process.env.DB_USER);
console.log('DB_NAME:', process.env.DB_NAME);
console.log('DB_PASSWORD:', process.env.DB_PASSWORD);

// Define your table schema
const users = mysqlTable('users', {
  id: int('id').primaryKey().autoincrement(),
  name: varchar('name', { length: 256 }),
  email: varchar('email', { length: 256 }),
});

// Database connection and `db` are initialized inside main() to avoid top-level await
// `db` is initialized inside main(); no module-level db needed


const app = new Hono()


async function main() {
  console.log('Starting application...');

  try {
    console.log('Attempting to create database connection...');
    const connection = await createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });
    console.log('Database connection created successfully');

  const db = drizzle(connection, { schema, mode: 'planetscale' });
    console.log('Drizzle ORM initialized');

    //app.listen({ port: 3000, hostname: '0.0.0.0' })


    app.get('/', (c) => {
      return c.text('Hello Hono!')
    })

    // Προσθήκη νέας διαδρομής POST για τη δημιουργία πελάτη
    app.post('/customers', async (c) => {
      try {
        const body = await c.req.json();

        // Έλεγχος εάν το identityNumber υπάρχει ήδη στη βάση δεδομένων
        const existingCustomer = await db.select({ id: customers.id })
          .from(customers)
          .where(eq(customers.identityNumber, body.identityNumber))
          .limit(1);
          //εαν υπαρχει αγνοησε την προσπαθεια
        if (existingCustomer[0]) {
          console.log(existingCustomer[0])
          return c.json({ error: 'Identity number already exists' }, 400); //επιστρεφει σφαλμα 400
        }

        // Βασικοί έλεγχοι εγκυρότητας
        if (!body.firstName || !body.lastName || !body.identityNumber || !body.gender || !body.birthDate) {
          return c.json({ error: 'Missing required fields' }, 400);
        }

        // Περισσότεροι έλεγχοι εγκυρότητας
        //εαν λειπει καποιο απο τα 5 απαιτουμενα πεδια αγνοησε την προσπαθεια
        //πρεπει το format να ειναι 1 κεφαλαιο γραμμα ακολουθουμενο απο τουλαχιστον 2 μικρα γραμματα
        if (!/^[A-Z]{1}[a-z]{2,}$/.test(body.firstName) || !/^[A-Z]{1}[a-z]{2,}$/.test(body.lastName)) {
          return c.json({ error: 'Invalid first name or last name format' }, 400);
        }

// Ελεγχος φορματ αριθμου ταυτοτητας
//πρεπει το format να ειναι 2 κεφαλαια γραμματα ακολουθουμενα απο 6 ψηφια
        if (!/^[A-Z]{2}[0-9]{6}$/.test(body.identityNumber)) {
          return c.json({ error: 'Invalid identity number format' }, 400);
        }
//ελεγχος φυλου
//πρεπει να ειναι male ή female
        if (!['male', 'female'].includes(body.gender)) {
          return c.json({ error: 'Invalid gender' }, 400);
        }

        // Έλεγχος ηλικίας
        const birthDate = new Date(body.birthDate);
        const age = (new Date().getTime() - birthDate.getTime()) / (1000 * 60 * 60 * 24 * 365.25);
        //εαν ο πελατης ειναι μικροτερος απο 16 αγνοησε την προσπαθεια
        if (age < 16) {
          return c.json({ error: 'Customer must be at least 16 years old' }, 400);
        }

        // Δημιουργία νέου πελάτη
        const newCustomer = {
          //φτιαχνει μοναδικο id το οποιο χρησιμοποιειται και σαν foreign key στους υπολοιπους πινακες
          id: randomUUID(),
          // createdAt should be a Date to match the `date` column type
          createdAt: new Date(),
          identityNumber: body.identityNumber,
          firstName: body.firstName,
          lastName: body.lastName,
          gender: body.gender,
          // store birthDate as Date
          birthDate: new Date(body.birthDate),
        };

        // Χρήση συναλλαγής για την εισαγωγή πελάτη, διευθύνσεων και τηλεφωνικών αριθμών
        await db.transaction(async (trx) => {
          await trx.insert(customers).values(newCustomer);
//αν υπαρχουν διευθυνσεις
          if (body.addresses && Array.isArray(body.addresses)) {
            for (const address of body.addresses) {
              await trx.insert(addresses).values({
                customerId: newCustomer.id,
                address,
              });
            }
          }
//αν υπαρχουν τηλεφωνα
          if (body.phoneNumbers && Array.isArray(body.phoneNumbers)) {
            for (const phoneNumber of body.phoneNumbers) {
              await trx.insert(phoneNumbers).values({
                customerId: newCustomer.id,
                phoneNumber,
              });
            }
          }
        });

        return c.json({ message: 'Customer created successfully', customer: newCustomer }, 201);
      } catch (error) {
        //εαν βγαλει σφαλμα 
        console.error('Error creating customer:', error);
        return c.json({ error: 'Internal server error' }, 500);
      }
    });

    app.get('/customers/search', async (c) => {
      try {
        const query = c.req.query();
        let whereConditions = [];

        // Δημιουργία συνθηκών αναζήτησης για κάθε πεδίο

        //εαν υπαρχει firstName στο query
        if (query.firstName) {
          whereConditions.push(like(customers.firstName, `%${query.firstName}%`));
        }
        //εαν υπαρχει lastName στο query
        if (query.lastName) {
          whereConditions.push(like(customers.lastName, `%${query.lastName}%`));
        }
        //εαν υπαρχει identityNumber στο query
        if (query.identityNumber) {
          whereConditions.push(like(customers.identityNumber, `%${query.identityNumber}%`));
        }
        //εαν υπαρχει φυλο στο query
        if (query.gender) {
          whereConditions.push(eq(customers.gender, query.gender));
        }
        //εαν υπαρχει birthDate στο query
        if (query.birthDate) {
          whereConditions.push(eq(customers.birthDate, new Date(query.birthDate)));
        }
        // Προσθέστε περισσότερα πεδία αναζήτησης εδώ αν χρειάζεται
//βαλαμε φιλτρα για τα πεδια που ζητηθηκαν
//μας εμφανιζει μονο τα αποτελεσματα που πληρουν τα κριτηρια και μας τα ταξινομει
        let searchResults;
        if (whereConditions.length > 0) {
          searchResults = await db
            .select() 
            .from(customers) //απο που διαλεγει τα δεδομενα
            .where(and(...whereConditions)) //εφαρμογη φιλτρων
            .orderBy( //ταξινομηση
              asc(customers.lastName), 
              asc(customers.firstName),
              asc(customers.identityNumber)
            );
        }
        // else {
        //   // Αν δεν υπάρχουν κριτήρια αναζήτησης, επιστρέφουμε όλους τους πελάτες
        //   searchResults = await db
        //     .select()
        //     .from(customers)
        //     .orderBy(
        //       asc(customers.lastName),
        //       asc(customers.firstName),
        //       asc(customers.identityNumber)
        //     );
        // }

        return c.json(searchResults); // Επιστροφή των αποτελεσμάτων αναζήτησης
      } catch (error) {
        console.error('Error searching customers:', error);
        return c.json({ error: 'Internal server error' }, 500); // Επιστροφή σφάλματος σε περίπτωση αποτυχίας
      }
    });


    //Διαδρομή για την ανάκτηση ενός συγκεκριμένου πελάτη ή όλων των πελατών
    app.get('/customers/:id?', async (c) => { //με το id? σημαινει οτι το id ειναι προαιρετικο
      try { //και εαν βαλω /customers μου επιστρεφει ολους τους πελατες
        const id = c.req.param('id');

        if (id) {
          // Ανάκτηση συγκεκριμένου πελάτη
          const customer = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
//εαν δεν βρεθει επιστρεφει σφαλμα 404
          if (customer.length === 0) {
            return c.json({ error: 'Customer not found' }, 404);
          }
//επιστρεφει τον συγκεκριμενο πελατη
          return c.json(customer[0]);
        } else {
          // Ανάκτηση όλων των πελατών εαν δεν δοθει id
          const allCustomers = await db.select().from(customers);
          return c.json(allCustomers);
        }
        // End of if-else
          //επιστρεφει ολους τους πελατες εαν δεν δωθει id
      } catch (error) {
        console.error('Error retrieving customer(s):', error);
        return c.json({ error: 'Internal server error' }, 500);
      }
    });
//Διαδρομή για τη διαγραφή πελάτη
    app.delete('/customers/:id', async (c) => { //εδω το id ειναι υποχρεωτικο και πρεπει να το βαλουμε στο path
      try {
        //παρνουμε το id απο το path
        const id = c.req.param('id');

        // Ελέγχουμε αν ο πελάτης υπάρχει
        const existingCustomer = await db.select({ id: customers.id })
          .from(customers)
          .where(eq(customers.id, id))
          .limit(1);
//εαν δεν υπαρχει επιστρεφει σφαλμα 404
        if (existingCustomer.length === 0) {
          return c.json({ error: 'Customer not found' }, 404);
        }

        // Πρώτα διαγράφουμε τις σχετικές διευθύνσεις
        await db.delete(addresses).where(eq(addresses.customerId, id));

        // Μετά διαγράφουμε τους σχετικούς τηλεφωνικούς αριθμούς
        await db.delete(phoneNumbers).where(eq(phoneNumbers.customerId, id));

        // Μετά διαγράφουμε τον πελάτη
        await db.delete(customers).where(eq(customers.id, id));
//επιστρεφει επιβεβαιωση διαγραφης
        return c.json({ message: 'Customer and related addresses and phonenumbers deleted successfully' }, 200);
      } catch (error) {
        console.error('Error deleting customer:', error); //καταγραφη σφαλματος
        return c.json({ error: 'Internal server error' }, 500); //επιστρεφει σφαλμα 500
      }
    });
//Διαδρομή για την ενημέρωση πελάτη
    app.put('/customers/:id', async (c) => { //εδω το id ειναι υποχρεωτικο και πρεπει να το βαλουμε στο path
      try {
        const id = c.req.param('id'); //παρνουμε το id απο το path
        const body = await c.req.json(); //δεδομενα απο το request body

        // Έλεγχος αν ο πελάτης υπάρχει
        const existingCustomer = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
        if (existingCustomer.length === 0) {
          return c.json({ error: 'Customer not found' }, 404); //εαν δεν υπαρχει επιστρεφει σφαλμα 404
        }

        const customer = existingCustomer[0]; //  παλιος πελατης

        // Συνάρτηση ελέγχου εγκυρότητας
        const isValid = (value: string, pattern: RegExp) => pattern.test(value); //επιστρεφει true ή false αναλογα αν το value ταιριαζει με το pattern

        const updateFields: Partial<typeof customer> = {}; //πεδια που θα ενημερωθουν

        if (body.firstName !== undefined) { //εαν υπαρχει firstName στο request body
          if (!isValid(body.firstName, /^[A-Z][a-z]{2,}$/)) { //πρεπει το format να ειναι 1 κεφαλαιο γραμμα ακολουθουμενο απο τουλαχιστον 2 μικρα γραμματα
            return c.json({ error: 'Invalid first name format' }, 400); //επιστρεφει σφαλμα 400
          }
          updateFields.firstName = body.firstName; //προσθετει το πεδιο που θα ενημερωθει
        }

        if (body.lastName !== undefined) { //εαν υπαρχει lastName στο request body
          if (!isValid(body.lastName, /^[A-Z][a-z]{2,}$/)) { //πρεπει το format να ειναι 1 κεφαλαιο γραμμα ακολουθουμενο απο τουλαχιστον 2 μικρα γραμματα
            return c.json({ error: 'Invalid last name format' }, 400);
          }
          updateFields.lastName = body.lastName; //προσθετει το πεδιο που θα ενημερωθει
        }

        if (body.identityNumber !== undefined) { //εαν υπαρχει identityNumber στο request body
          if (!isValid(body.identityNumber, /^[A-Z]{2}[0-9]{6}$/)) { //πρεπει το format να ειναι 2 κεφαλαια γραμματα ακολουθουμενα απο 6 ψηφια
            return c.json({ error: 'Invalid identity number format' }, 400);
          }
          updateFields.identityNumber = body.identityNumber;
        }

        if (body.gender !== undefined) { //εαν υπαρχει φυλο στο request body
          if (!['male', 'female'].includes(body.gender)) { //πρεπει να ειναι male ή female
            return c.json({ error: 'Invalid gender' }, 400);
          }
          updateFields.gender = body.gender;
        }

        // Handle addresses and phoneNumbers by updating the related tables
        if (body.addresses !== undefined) { //εαν υπαρχουν διευθυνσεις στο request body
          if (!Array.isArray(body.addresses)) {   //πρεπει να ειναι array
            return c.json({ error: 'addresses must be an array' }, 400); 
          }
          // Replace existing addresses with the provided list   //διαγραφει τις παλιες και βαζει τις καινουργιες
          await db.transaction(async (trx) => { //χρηση συναλλαγης
            await trx.delete(addresses).where(eq(addresses.customerId, id)); //διαγραφη παλιων διευθυνσεων
            for (const address of body.addresses) { //εισαγωγη καινουργιων διευθυνσεων
              await trx.insert(addresses).values({ customerId: id, address }); //εισαγωγη διευθυνσης
            }
          });
        }
//εαν υπαρχουν τηλεφωνα στο request body
        if (body.phoneNumbers !== undefined) {
          if (!Array.isArray(body.phoneNumbers) || !body.phoneNumbers.every((num: string) => /^\d{10}$/.test(num))) { //πρεπει να ειναι array απο 10 ψηφιους αριθμους
            return c.json({ error: 'Invalid phoneNumbers format; expected array of 10 digit strings' }, 400); //επιστρεφει σφαλμα 400
          }
          // Replace existing phone numbers with the provided list
          await db.transaction(async (trx) => { //χρηση συναλλαγης
            await trx.delete(phoneNumbers).where(eq(phoneNumbers.customerId, id)); //διαγραφη παλιων τηλεφωνικων αριθμων
            for (const phoneNumber of body.phoneNumbers) { //εισαγωγη καινουργιων τηλεφωνικων αριθμων
              await trx.insert(phoneNumbers).values({ customerId: id, phoneNumber }); //εισαγωγη τηλεφωνικου αριθμου
            } 
          });
        }

        // Update other customer fields if present
        if (Object.keys(updateFields).length > 0) { //εαν υπαρχουν πεδια για ενημερωση
          await db.update(customers).set(updateFields).where(eq(customers.id, id)); //ενημερωση πεδιων
          return c.json({ message: 'Customer updated successfully', updatedFields: updateFields }, 200); //επιστρεφει επιβεβαιωση ενημερωσης
        }

        return c.json({ message: 'Customer updated successfully' }, 200); //επιστρεφει επιβεβαιωση ενημερωσης
 
      } catch (error) {
        console.error('Error updating customer:', error);
        return c.json({ error: 'Internal server error' }, 500); //επιστρεφει σφαλμα 500
      }
    });
// End of main function
    const port = process.env.PORT || 3001; // Use PORT from environment or default to 3001
    console.log(`Server is starting on port ${port}`); //καταγραφη πορτας

    // Start the server
    Bun.serve({
      port: port, 
      fetch: app.fetch, // Hono app fetch handler
    });

    console.log(`Server is running on http://localhost:${port}`); //καταγραφη εκκινησης server
  } catch (error) {
    console.error('Error during application setup:', error); //καταγραφη σφαλματος
    process.exit(1);
  }
}

main().catch(error => { //καταγραφη σφαλματος
  console.error('Unhandled error:', error); 
  process.exit(1);
});

export default app;