import mysql from 'mysql2/promise';
import { drizzle } from 'drizzle-orm/mysql2';

const MAX_RETRIES = 5;
const RETRY_INTERVAL = 5000; // 5 seconds

async function createConnection(retries = MAX_RETRIES): Promise<ReturnType<typeof drizzle>> {
  try {
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      multipleStatements: true,
    });

    console.log('Successfully connected to the database');
    return drizzle(connection);
  } catch (error) {
    if (retries > 0) {
      console.log(`Failed to connect to the database. Retrying in ${RETRY_INTERVAL / 1000} seconds...`);
      await new Promise(resolve => setTimeout(resolve, RETRY_INTERVAL));
      return createConnection(retries - 1);
    } else {
      console.error('Max retries reached. Unable to connect to the database.');
      throw error;
    }
  }
}

export const db = await createConnection();