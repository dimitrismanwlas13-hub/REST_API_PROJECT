#!/bin/sh

set -e

echo "Start script is running..."

echo "Environment variables:"
env

echo "Running migrations..."
bun run src/migrate.ts

if [ $? -ne 0 ]; then
    echo "Migration failed. Exiting."
    exit 1
fi

echo "Migration completed. Starting main application..."
exec bun run src/index.ts