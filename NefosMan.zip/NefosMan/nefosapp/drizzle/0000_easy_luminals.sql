CREATE TABLE `addresses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customer_id` varchar(36) NOT NULL,
	`address` varchar(256) NOT NULL,
	CONSTRAINT `addresses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` varchar(36) NOT NULL,
	`created_at` date,
	`identity_number` varchar(8) NOT NULL,
	`first_name` varchar(256) NOT NULL,
	`last_name` varchar(256) NOT NULL,
	`gender` varchar(6) NOT NULL,
	`birth_date` date NOT NULL,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`),
	CONSTRAINT `customers_identity_number_unique` UNIQUE(`identity_number`)
);
--> statement-breakpoint
CREATE TABLE `phone_numbers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customer_id` varchar(36) NOT NULL,
	`phone_number` varchar(15) NOT NULL,
	CONSTRAINT `phone_numbers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `addresses` ADD CONSTRAINT `addresses_customer_id_customers_id_fk` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `phone_numbers` ADD CONSTRAINT `phone_numbers_customer_id_customers_id_fk` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `customer_id_idx` ON `addresses` (`customer_id`);--> statement-breakpoint
CREATE INDEX `identity_number_idx` ON `customers` (`identity_number`);--> statement-breakpoint
CREATE INDEX `customer_id_idx` ON `phone_numbers` (`customer_id`);